import React, { Component } from 'react';
import productStyles from './ProductDetails.module.css';
import ProductDetail from '../../components/ProductDetail/ProductDetail';
import { connect } from 'react-redux';
import * as actionTypes from '../../store/actions';

class ProductDetails extends Component {
    // shouldComponentUpdate(nextProps, nextState) {
    //     if(this.props.product) {
    //         return true;
    //     } else {
    //         return false;
    //     }
    // }
    componentDidMount() {
        console.log(this.props.match.params.id, 'check product details');
        const id = this.props.match.params.id;
        this.props.getProductDetail(id);
    }

    addProductToCart = (id) => {
        this.props.addProductToCart(id);
    }

    render() {
        console.log(this.props.product, 'check main product')
        if(this.props.product && Object.keys(this.props.product).length) {
            const images = require.context('../../assets/images', true);
            let img = images('./' + this.props.product.url);
            return (
                <div className={productStyles.productDetails}>
                    <img className={productStyles.productImage} src={img} alt="product" />
                    <ProductDetail addCart={() => this.addProductToCart(this.props.product.id)} product={this.props.product}/>
                </div>
            )
        } else {
            return null;
        }
    }
}

const mapStateToProps = (state) => {
    return {
        product: state.productDetail
    }
}

const mapDispatchToProps = dispatch => {
    return {
        getProductDetail: (id) => dispatch({ type: actionTypes.GET_PRODUCT_DETAIL, productId: id}),
        addProductToCart : (id) => dispatch( { type: actionTypes.ADD_TO_CART, productId: id } )
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductDetails);