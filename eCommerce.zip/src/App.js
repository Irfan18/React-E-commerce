import React from 'react';
import './App.css';
import Layout from './hoc/Layout/Layout';
import Home from './containers/Home/Home';
import ProductDetails from './containers/ProductDetails/ProductDetails';
import ProductsCart from './containers/ProductsCart/ProductsCart';
import { Switch, Route } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <Layout>
        <Switch>
          <Route path="/products/cart" component={ProductsCart} />
          <Route path="/product/:id/:collectionName/:productName" component={ProductDetails} />
          <Route path="/" component={Home} />
        </Switch>
      </Layout>
    </div>
  );
}

export default App;
