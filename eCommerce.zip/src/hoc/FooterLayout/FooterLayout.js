import React from 'react';
import Heading from '../../components/Footer/Heading/Heading';
import FooterLayoutStyles from './FooterLayout.module.css';

const footerLayout = props => {
    return (
        <div className={FooterLayoutStyles.footer_layout}>
            <Heading>{props.heading}</Heading>
            {props.children}
        </div>
    )
}

export default footerLayout;