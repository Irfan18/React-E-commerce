const auxilliary = props => props.children;

export default auxilliary;