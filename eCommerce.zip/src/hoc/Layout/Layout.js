import React from 'react';
import layoutStyles from './Layout.module.css';
import Header from '../../containers/Header/Header';
import Footer from '../../containers/Footer/Footer';

const layout = props => {
    return (
        <div className={layoutStyles.layout}>
            <Header />
            <main>
                {props.children}
            </main>
            <Footer />
        </div>
    )
}

export default layout;