import React from 'react';
import BagImage from '../../assets/images/bag.png';
import productStyles from './ProductThumbnail.module.css';

const productThumbnail = props => {
    return (
        <figure className={productStyles.container}>
            <img className={productStyles.image} src={BagImage} alt="product"/>
            <figcaption className={productStyles.product_info}>
                <h3 className={productStyles.heading}>Chanel - Fashion Bag</h3>
                <p>$189.00</p>
            </figcaption>
        </figure>
    )
}

export default productThumbnail;