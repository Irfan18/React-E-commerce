import React from 'react';
import LanguageStyles from './LanguageNavigation.module.css';
import Navigation from './Navigation/Navigation';

const languageNav = props => {
    // const navLanguages = Object.keys(props.navigation)
    // const navCodes = Object.keys(props.navigation).map( item => {
    //     return props.navigation[item];
    // });
    const navLanguages = Object.keys(props.navigation).map( item => {
        return { value: item, pathName: props.navigation[item].pathName }
    });

    const navCodes = Object.keys(props.navigation).map( item => {
        return { value: props.navigation[item].code, pathName: props.navigation[item].pathName }
    })

    return (
        <nav className={LanguageStyles.language}>
            <Navigation navData={navLanguages} />
            <Navigation navData={navCodes} />
        </nav>
    )
}

export default languageNav;