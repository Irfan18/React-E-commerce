import React from 'react';
import NavigationItem from './NavigationItem/NavigationItem';
import navStyles from './Navigation.module.css';

const Navigation = props => {
    return (
        <ul className={navStyles.navigation}>
            {props.navData.map( item => {
                return <NavigationItem key={item.pathName} path={item.pathName} exact={!item.pathName}>{item.value}</NavigationItem>
            })}
        </ul>
    )
}

export default Navigation;