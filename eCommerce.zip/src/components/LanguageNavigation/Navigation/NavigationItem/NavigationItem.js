import React from 'react';
import { NavLink } from 'react-router-dom';
import navItemStyles from './NavigationItem.module.css';

const NavigationItem = props => (
    <li className={navItemStyles.item}>
        <NavLink to={"/" + props.path} activeClassName={navItemStyles.active} exact>{props.children}</NavLink>
    </li>
)

export default NavigationItem;