import React from 'react';
import BannerImage from '../../assets/images/banner.jpg';
import bannerStyles from './Banner.module.css';

const banner = props => {
    return (
        <img className={bannerStyles.banner} src={BannerImage} alt="banner" />
    )
}

export default banner;