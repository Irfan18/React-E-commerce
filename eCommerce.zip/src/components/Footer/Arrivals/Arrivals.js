import React from 'react';
import Auxilliary from '../../../hoc/Auxilliary/Auxilliary';
import ProductThumbnail from '../../ProductThumbnail/ProductThumbnail';

const arrivals = props => {
    return (
        <Auxilliary>
           <ProductThumbnail />
           <ProductThumbnail />
        </Auxilliary>
    )
}

export default arrivals;