import React from 'react';
import Auxilliary from '../../../hoc/Auxilliary/Auxilliary';
import SupportStyles from './Support.module.css';

const support = props => {
    return (
        <Auxilliary>
           <ul className={SupportStyles.container}>
               <li>Terms & Conditions</li>
               <li>Delivery</li>
               <li>Secure Payment</li>
               <li>Contact Us</li>
               <li>Refunds</li>
               <li>Track Orders</li>
               <li>Services</li>
           </ul>
        </Auxilliary>
    )
}

export default support;