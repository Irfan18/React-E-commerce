import React from 'react';
import NavigationItemStyles from './NavigationItem.module.css';
import { NavLink } from 'react-router-dom';

const navigationItem = props => {
    return (
        <li className={NavigationItemStyles.nav_item}>
            <NavLink to={"/" + props.children} activeClassName={NavigationItemStyles.active} exact={true}>{props.children}</NavLink>
        </li>
    )
}

export default navigationItem;