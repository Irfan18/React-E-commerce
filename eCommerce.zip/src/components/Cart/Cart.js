import React from 'react';
import cartStyles from './Cart.module.css';
import Button from '../UI/Button/Button';

const cart = props => {
    const images = require.context('../../assets/images', true);
    let img = images('./' + props.url);
    return (
        <tr className={cartStyles.cart}>
            <td>
                <div className={cartStyles.cartImage}>
                    <img className={cartStyles.image} src={img} alt="product"/>
                </div>
            </td>
            <td>{props.productName}</td>
            <td>{props.brandName}</td>
            <td>{"$" + props.price}</td>
            <td>
                <div className={cartStyles.buttonWrapper}>
                    <Button clicked={props.removeClicked}>Remove</Button>
                </div>
            </td>
        </tr>
    )
}

export default cart;