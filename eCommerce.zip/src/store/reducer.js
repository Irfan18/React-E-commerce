import * as actionTypes from './actions';

const initialState = {
    products: [
        {
            id: "001",
            productName: "slimm pants",
            brandName: "Calvin klein",
            price: "279,00",
            url: "pants.jpg",
            collectionName: "featured",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "002",
            productName: "Gummy Sweater",
            brandName: "Calvin klein",
            price: "279,00",
            url: "sweater.jpg",
            collectionName: "featured",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "003",
            productName: "Shirt",
            brandName: "Calvin klein",
            price: "229,00",
            url: "shirt.jpg",
            collectionName: "featured",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "004",
            productName: "Tshirt Blue",
            brandName: "Mc Neal",
            price: "314,00",
            url: "t-shirt.jpg",
            collectionName: "featured",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "005",
            productName: "slimm pants",
            brandName: "Calvin klein",
            price: "279,00",
            url: "pants.jpg",
            collectionName: "featured",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "006",
            productName: "Tshirt Blue",
            brandName: "Mc Neal",
            price: "314,00",
            url: "t-shirt.jpg",
            collectionName: "featured",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "007",
            productName: "Gummy Sweater",
            brandName: "Calvin klein",
            price: "279,00",
            url: "sweater.jpg",
            collectionName: "featured",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "008",
            productName: "slimm pants",
            brandName: "Calvin klein",
            price: "279,00",
            url: "pants.jpg",
            collectionName: "featured",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "j-001",
            productName: "Slim Jacket",
            brandName: "Mc Neal",
            price: "379,00",
            url: "jacket.jpg",
            collectionName: "jackets",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "j-002",
            productName: "Gummy Sweater",
            brandName: "Calvin klein",
            price: "279,00",
            url: "sweater.jpg",
            collectionName: "jackets",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "j-003",
            productName: "Shirt",
            brandName: "Calvin klein",
            price: "229,00",
            url: "shirt.jpg",
            collectionName: "jackets",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "j-004",
            productName: "Tshirt Blue",
            brandName: "Mc Neal",
            price: "314,00",
            url: "t-shirt.jpg",
            collectionName: "jackets",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "j-005",
            productName: "Gummy Sweater",
            brandName: "Calvin klein",
            price: "279,00",
            url: "sweater.jpg",
            collectionName: "jackets",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "j-006",
            productName: "Shirt",
            brandName: "Calvin klein",
            price: "229,00",
            url: "shirt.jpg",
            collectionName: "jackets",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "j-007",
            productName: "Gummy Sweater",
            brandName: "Calvin klein",
            price: "279,00",
            url: "sweater.jpg",
            collectionName: "jackets",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "j-008",
            productName: "slimm pants",
            brandName: "Calvin klein",
            price: "279,00",
            url: "pants.jpg",
            collectionName: "jackets",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "s-001",
            productName: "Gummy Sweater",
            brandName: "Calvin klein",
            price: "279,00",
            url: "sweater.jpg",
            collectionName: "sweaters",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "s-002",
            productName: "Tshirt Blue",
            brandName: "Mc Neal",
            price: "314,00",
            url: "t-shirt.jpg",
            collectionName: "sweaters",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "s-003",
            productName: "Shirt",
            brandName: "Calvin klein",
            price: "229,00",
            url: "shirt.jpg",
            collectionName: "sweaters",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "s-004",
            productName: "Tshirt Blue",
            brandName: "Mc Neal",
            price: "314,00",
            url: "t-shirt.jpg",
            collectionName: "sweaters",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "s-005",
            productName: "Gummy Sweater",
            brandName: "Calvin klein",
            price: "279,00",
            url: "sweater.jpg",
            collectionName: "sweaters",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "s-006",
            productName: "Shirt",
            brandName: "Calvin klein",
            price: "229,00",
            url: "shirt.jpg",
            collectionName: "sweaters",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "s-007",
            productName: "Gummy Sweater",
            brandName: "Calvin klein",
            price: "279,00",
            url: "sweater.jpg",
            collectionName: "sweaters",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        },
        {
            id: "s-008",
            productName: "slimm pants",
            brandName: "Calvin klein",
            price: "279,00",
            url: "pants.jpg",
            collectionName: "sweaters",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam diam, finibus id sem at, mollis dapibus nulla. Aliquam sit amet consectetur leo. Sed eleifend ut purus non convallis. Pellentesque sit amet lorem eu augue rutrum pulvinar a non urna. Phasellus imperdiet, lorem non efficitur condimentum, nibh arcu convallis urna, in vulputate erat nibh et enim.",
            cart: false
        }
    ],
    productsWithCollection: [],
    productDetail: {},
    productCart: []
}

const  reducer = (state = initialState, action) => {
    switch(action.type) {
        case actionTypes.GET_PRODUCT_COLLECTION:
            const products = state.products.filter( product => product.collectionName === action.collectionName );
            return {
                ...state,
                productsWithCollection: products
            }
        case actionTypes.GET_PRODUCT_DETAIL:
            const product = state.products.filter( product => product.id === action.productId )[0];
            return {
                ...state,
                productDetail: { ...product }
            }
        case actionTypes.ADD_TO_CART:
            const cartProduct = state.products.filter( product => product.id === action.productId );
            const updatedProductsWithCollection = state.productsWithCollection.map( product => {
                if(product.id === action.productId) {
                    product.cart = true;
                    return product;
                }
                return product;
            });
            const updatedProducts = state.products.map( product => {
                if(product.id === action.productId) {
                    product.cart = true;
                    return product;
                }
                return product;
            })

            let updatedProductDetail = { ...state.productDetail };
            console.log(state.productDetail.id, action.productId)
            if(state.productDetail.id === action.productId) {
                updatedProductDetail.cart = true;
            }

            return {
                ...state,
                productDetail: updatedProductDetail,
                products: updatedProducts,
                productsWithCollection: updatedProductsWithCollection,
                productCart: state.productCart.concat(cartProduct)
            }
        case actionTypes.REMOVE_FROM_CART:
            const cartProducts = state.productCart.filter( product => product.id !== action.productId );
            console.log(action.productId, 'in reducer')
            return {
                ...state,
                productCart: cartProducts
            }
        default: return state;
    }
}

export default reducer;