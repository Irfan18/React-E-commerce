import React from 'react';
import productsStyles from './ProductListing.module.css';
import ProductCard from '../ProductCard/ProductCard'; 

const productListing = props => {
    return (
        <div className={productsStyles.product}>
            {props.featured.map( product => {
                return <ProductCard key={product.id}
                    addCart={() => props.cartClicked(product.id)}
                    clicked={(event) => props.cardClicked(event, product.id, product.collectionName, product.productName)}
                    {...product}
                />
            })}
        </div>
    )
}

export default productListing;