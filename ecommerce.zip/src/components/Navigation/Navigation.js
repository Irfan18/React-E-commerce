import React from 'react';
import navigationStyles from './Navigation.module.css';
import NavigationItem from './NavigationItem/NavigationItem';

const navigation = props => {
    return (
        <nav className={navigationStyles.navigation_container}>
            <ul className={navigationStyles.navigation}>
                {props.navItems.map( item => {
                    return <NavigationItem key={item}>{item}</NavigationItem>
                })}
            </ul>
        </nav>
    )
}

export default navigation;