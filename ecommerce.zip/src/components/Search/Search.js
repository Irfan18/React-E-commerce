import React from 'react';
import searchStyles from './Search.module.css';

const searchBox = props => {
    return (
        <div className={searchStyles.search_box}>
            <input className={searchStyles.search} type="text" name="search" placeholder="SEARCH" autoComplete="off" />
            <span className={searchStyles.search_icon}><i className="fa fa-search" aria-hidden="true"></i></span>
        </div>
    )
}

export default searchBox;