import React from 'react';
import productStyles from './ProductDetail.module.css';
import Button from '../UI/Button/Button';

const ProjectDetail = props => {
    return (
        <div className={productStyles.productDetail}>
            <h3>{props.product.brandName}</h3>
            <h2>{props.product.productName}</h2>
            <p className={productStyles.price}>{'$' + props.product.price}</p>
            <p className={productStyles.description}>{props.product.description}</p>
            <div className={productStyles.buttonWrapper}>
                {props.product.cart ? 
                    <p>Added To Cart</p>
                :
                    <Button clicked={props.addCart}>Add To Cart</Button>
                }
            </div>
        </div>
    )
}

export default ProjectDetail;