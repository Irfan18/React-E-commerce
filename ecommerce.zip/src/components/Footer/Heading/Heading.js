import React from 'react';
import headingStyles from './Heading.module.css';

const heading = props => {
    return (
        <h2 className={headingStyles.heading}>{props.children}</h2>
    )
}

export default heading;