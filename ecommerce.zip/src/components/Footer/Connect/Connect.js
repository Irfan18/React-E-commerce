import React from 'react';
import Auxilliary from '../../../hoc/Auxilliary/Auxilliary';
import connectStyles from './Connect.module.css';

const connect = props => {
    return (
        <Auxilliary>
            <h3 className={connectStyles.heading}>Modello - eCommerce</h3>
            <p className={connectStyles.address}>4 East 80th Street, New York, NY <span>+88 897 654 321</span> <span>say@hello.com</span></p>
            <div className={connectStyles.icons_container}>
                <span><i className="fa fa-facebook" aria-hidden="true"></i></span>
                <span><i className="fa fa-twitter" aria-hidden="true"></i></span>
                <span><i className="fa fa-facebook" aria-hidden="true"></i></span>
                <span><i className="fa fa-google-plus   " aria-hidden="true"></i></span>
            </div>
        </Auxilliary>
    )
}

export default connect;