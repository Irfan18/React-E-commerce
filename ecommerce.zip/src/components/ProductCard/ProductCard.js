import React from 'react';
import cardStyles from './ProductCard.module.css';
import Button from '../UI/Button/Button';

const productCard = props => {
    const images = require.context('../../assets/images', true);
    let img = images('./' + props.url);
    return (
        <div className={cardStyles.productCard} onClick={props.clicked}>
            <div className={cardStyles.imageWrapper}>
                <img className={cardStyles.productImage} src={img} alt="product" />
            </div>
            <span className={cardStyles.dash}>&#11835;</span>
            <span className={cardStyles.brandName}>{props.brandName}</span>
            <span className={cardStyles.productName}>{props.productName}</span>
            <span className={cardStyles.productPrice}>{'$' + props.price}</span>
            <div className={cardStyles.buttonWrapper}>
                { props.cart ? 
                    <p>Added in Cart</p>
                : 
                    <Button clicked={props.addCart}>Add to Cart</Button>
                }
            </div>
        </div>
    )
}

export default productCard;