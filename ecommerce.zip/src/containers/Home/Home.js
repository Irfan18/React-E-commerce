import React, { Component } from 'react';
import homeStyles from './Home.module.css';
import Banner from '../../components/Banner/Banner';
import ProductListing from '../../components/ProductListing/ProductListing';
import { connect } from 'react-redux';
import * as actionTypes from '../../store/actions';

class Home extends Component {
    state = {
      
    }
    
    componentDidMount() {
       this.handleNavigationChange();
    }

    componentDidUpdate(prevProps) {
        if(this.props.location.pathname !== prevProps.location.pathname) {
           this.handleNavigationChange();
        }
    }

    handleNavigationChange = () => {
        switch(this.props.history.location.pathname) {
            case "/": this.props.getProductsWithCollection("featured");
            break;
            case "/jackets": this.props.getProductsWithCollection("jackets");
            break;
            case "/sweaters": this.props.getProductsWithCollection("sweaters");
            break;
            default: this.props.getProductsWithCollection("featured");
        }
    }

    handleAddToCartClick = (id) => {
        this.props.addProductToCart(id);
    }

    handleProductClick = (event, id, collectionName, productName) => {
        console.log(event.target.nodeName, 'node name')
        if(event.target.nodeName !== "BUTTON") {
            this.props.history.replace(`/product/${id}/${collectionName}/${productName}`);
        } else {
            return;
        }
    }

    render() {
        return (
            <div className={homeStyles.home}>
                <Banner />
                <ProductListing cardClicked={this.handleProductClick} cartClicked={this.handleAddToCartClick} featured={this.props.productsWithCollection}/>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        productsWithCollection: state.productsWithCollection
    }
}

const mapDispatchToProps = dispatch => {
    return {
        getProductsWithCollection: (name) => dispatch({ type: actionTypes.GET_PRODUCT_COLLECTION, collectionName: name }),
        addProductToCart : (id) => dispatch( { type: actionTypes.ADD_TO_CART, productId: id } )
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Home);