import React, { Component } from 'react';
import headerStyles from './Header.module.css';
import Search from '../../components/Search/Search';
import Navigation from '../../components/Navigation/Navigation';
import LanguageNavigation from '../../components/LanguageNavigation/LanguageNavigation';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';

class Header extends Component {

    state = {
        languageNav: {
            eng: {
                code: "us",
                pathName: ""
            },
            de: {
                code: "eur",
                pathName: "eur"
            },
            pl: {
                code: "pln",
                pathName: "pln"
            }
        },
        navigationItems: [
            "jackets",
            "sweaters",
            "dresses",
            "skirts",
            "pants",
            "shorts",
            "shoes",
            "accessories"
        ]
    }

    redirectToCart = () => {
        console.log(this.props);
        this.props.history.replace('/products/cart');
    }

    render() {
        return (
            <header className={headerStyles.header}>
                <LanguageNavigation navigation={this.state.languageNav} />
                <div className={headerStyles.header_content}>
                    <div className={headerStyles.layout_flex_alignment}>
                        <div className={headerStyles.signup_info}>
                            <span className={headerStyles.signup_icon}><i className="fa fa-user-o" aria-hidden="true"></i></span>
                            <span className={headerStyles.signup_text}>Welcome, you can <strong>login</strong> or <strong>register</strong></span>
                        </div>
                        <div className={headerStyles.product_interest_info}>
                            <span className={headerStyles.wishlist_details}>
                                <span className={headerStyles.wishlist_icon}><i className="fa fa-heart-o" aria-hidden="true"></i></span>
                                <span className={headerStyles.wishlist_text}>
                                    Wishlist:
                                </span>
                                <span className={headerStyles.wishlist_count}> <strong>2</strong></span>
                            </span>
                            <span onClick={this.redirectToCart} className={headerStyles.cart_details}>
                                <span className={headerStyles.cart_icon}><i className="fa fa-shopping-basket" aria-hidden="true"></i></span>
                                <span className={headerStyles.cart_text}>
                                    Shopping Cart:
                                </span>
                                <span className={headerStyles.cart_count}> <strong>{this.props.cartLength}</strong> item(s) - </span>
                                <span className={headerStyles.cart_total}><strong>$129.00</strong></span>
                            </span>
                        </div>
                    </div>
                    <div className={headerStyles.layout_flex_alignment}>
                        <div className={headerStyles.contact_info}>
                            <span className={headerStyles.contact_icon}><i className="fa fa-phone" aria-hidden="true"></i></span>
                            <span className={headerStyles.contact_text}>Hotline:</span>
                            <span className={headerStyles.contact_number}> <strong>+88 987 654 321</strong></span>
                        </div>
                        <Search />
                    </div>
                    <Navigation navItems={this.state.navigationItems}/>
                </div>
            </header>
        )
    }
}
const mapStateToProps = state => {
    return {
        cartLength: state.productCart.length
    }
}
const ShowTheLocationWithRouter = withRouter(Header);

export default connect(mapStateToProps)(ShowTheLocationWithRouter);