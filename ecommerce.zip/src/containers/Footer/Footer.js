import React, { Component } from 'react';
import footerStyles from './Footer.module.css';
import Connect from '../../components/Footer/Connect/Connect';
import Sales from '../../components/Footer/Sales/Sales';
import Arrivals from '../../components/Footer/Arrivals/Arrivals';
import Support from '../../components/Footer/Support/Support';
import FooterLayout from '../../hoc/FooterLayout/FooterLayout';

class Footer extends Component {
    render() {
        return (
            <footer>
                <div className={footerStyles.section_first}>
                    <div className={footerStyles.content}>
                        <FooterLayout heading="Connect with us">
                            <Connect />
                        </FooterLayout>
                        <FooterLayout heading="Holiday sales">
                            <Sales />
                        </FooterLayout>
                        <FooterLayout heading="New arrivals">
                            <Arrivals />
                        </FooterLayout>
                        <FooterLayout heading="Our support">
                            <Support />
                        </FooterLayout>
                    </div>
                </div>
                <div className={footerStyles.section_second}>
    
                </div>
            </footer>
        )
    }
}

export default Footer;