import React, { Component } from 'react';
import Cart from '../../components/Cart/Cart';
import productStyles from './ProductsCart.module.css';
import { connect } from 'react-redux';
import * as actionTypes from '../../store/actions';

class ProductsCart extends Component {
    state = {
    }

    removeProductFromCart = (id) => {
        this.props.removeProductFromCart(id)
    }

    render() {
        return (
            <div className={productStyles.productsCart}>
                { this.props.carts.length ? 
                    <table>
                        <thead></thead>
                        <tbody>
                            {this.props.carts.map( product => {
                                return <Cart 
                                removeClicked={() => this.removeProductFromCart(product.id)} 
                                key={product.id} 
                                {...product} />
                            })}
                        </tbody>
                    </table>
                :
                    <p>The cart is empty. Please add product to the cart</p>
                }
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        carts: state.productCart
    }
}

const mapDispatchToProps = dispatch => {
    return {
        removeProductFromCart: (id) => dispatch({ type: actionTypes.REMOVE_FROM_CART, productId: id })
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductsCart);